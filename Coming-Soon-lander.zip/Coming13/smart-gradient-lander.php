<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-gradient-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-gradient-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-gradient-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-gradient-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-gradient-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-circle"></div>
                <span>E</span>
            </div>
        </div>
        <!-- End Preloader -->
        
        <!-- Start Coming Soon Area -->
        <div class="coming-soon-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="coming-soon-content">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>

                            <h5>extensionsdev Status 77</h5>
                            <h1>We are launching very soon!</h1>
                            <p>An amazing new Chrome Extension is on its way.</p>

                            <div class="btn-box">
                                <button class="btn btn-primary notify-btn"><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION" style="color: #fff;">Install</a> <i class="fas fa-chevron-right"></i></button>
                            </div>
                            <div class="link-third">
                                <ul>
                                    <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                                    <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                                    <li><a href="/?a=about">About | &nbsp;</a></li>
                                    <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                                </ul>
                            </div>
                        </div>

                        <div id="timer">
                            <div id="days"></div>
                            <div id="hours"></div>
                            <div id="minutes"></div>
                            <div id="seconds"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="shape1"><img src="pages/landerthemes/smart-gradient-lander/img/circle1.png" alt="image"></div>
            <div class="shape2"><img src="pages/landerthemes/smart-gradient-lander/img/circle2.png" alt="image"></div>
        </div>
        <!-- End Coming Soon Area -->

        <!-- Sidebar Modal -->
        <div class="sidebar-modal">
            <div class="sidebar-modal-inner">
                <div class="about-area">
                    <div class="title">
                        <h2>About Us</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis suspendisse ultrices gravida. Risus commodo viverra. Quis suspendisse ultrices gravida.</p>
                    </div>
                </div>

                <div class="contact-area">
                    <div class="title">
                        <h2>Contact Us</h2>
                    </div>

                    <div class="contact-form">
                        <form id="contactForm">
                            <div class="form-group">
                                <input type="text" name="name" id="name" class="form-control" required data-error="Please enter your name" placeholder="Name">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <input type="email" name="email" id="email" class="form-control" required data-error="Please enter your email" placeholder="Email">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <textarea name="message" class="form-control" id="message" cols="30" rows="5" required data-error="Write your message" placeholder="Your Message"></textarea>
                                <div class="help-block with-errors"></div>
                            </div>

                            <button type="submit">Send Message</button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>
                        </form>
                    </div>

                    <div class="contact-info">
                        <div class="contact-info-content">
                            <h3>Contact us by Phone Number or Email Address</h3>
                            <h2>
                                <a href="tel:+0881306298615">+088 130 629 8615</a>
                                <span>OR</span>
                                <a href="mailto:emilono@gmail.com">emilono@gmail.com</a>
                            </h2>
    
                            <ul class="social">
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <span class="close-btn sidebar-modal-close-btn"><i class="fas fa-times"></i></span>
            </div>
        </div>
        <!-- End Sidebar Modal -->

        <!-- Subscribe Modal -->
        <div class="subscribe-modal">
            <div class="subscribe-modal-inner">
                <div class="subscribe-modal-content">
                    <div class="newsletter-header">
                        <div class="animation-icons">
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                            <span class="animate-icon"><i class="far fa-envelope"></i></span>
                        </div>
    
                        <img src="pages/landerthemes/smart-gradient-lander/img/bell-icon.png" alt="image">
                    </div>
    
                    <h2>Subscribe Newsletter</h2>
                    <p>Being the first to know always feels great. Signing up to our newsletter gives you exclusive access to our Grand Opening!</p>
    
                    <form class="newsletter-form" data-toggle="validator">
                        <input type="email" class="input-newsletter" placeholder="Enter email address" name="EMAIL" required autocomplete="off">
    
                        <button type="submit">Subscribe Now</button>
                        <div id="validator-newsletter" class="form-result"></div>
                    </form>
    
                    <span class="close-btn subscribe-modal-close-btn"><i class="fas fa-times"></i></span>
                </div>
            </div>
        </div>
        <!-- End Subscribe Modal -->
        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/bootstrap.min.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/wow.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/form-validator.min.js"></script>
        <!-- Contact Form Min JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/contact-form-script.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/smart-gradient-lander/js/main.js"></script>
    </body>
</html>