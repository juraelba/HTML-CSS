<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-static-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-static-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-static-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-static-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-static-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>
    </head>

    <body>
        
        <!-- Preloader -->
        <div class="preloader">
            <div class="spinner"></div>
        </div>
        <!-- End Preloader -->

        <!-- Start Coming Soon Area -->
        <section class="coming-soon-area">
            <div class="container-fluid p-0">
                <div class="row m-0">
                    <div class="col-lg-6 col-md-12 p-0">
                        <div class="coming-soon-content">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <div class="logo">
                                        <img src="img/logo.png" alt="logo">
                                    </div>

                                    <div id="timer">
                                        <div id="days"></div>
                                        <div id="hours"></div>
                                        <div id="minutes"></div>
                                        <div id="seconds"></div>
                                    </div>
                                    
                                    <h1>extensionsdev Status 77 is coming soon!</h1>

                                    <form class="newsletter-form" data-toggle="validator">

                                        <button type="submit" class="btn btn-primary"><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION" style="color: #fff;">Install</a></button>
                                    </form>

                                    <div class="social">
                                        <ul>
                                            <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                                            <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                                            <li><a href="/?a=about">About | &nbsp;</a></li>
                                            <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-12 p-0">
                        <div class="coming-soon-image">
                            <img src="pages/landerthemes/smart-static-lander/img/background.jpg" alt="image" style="object-fit: cover; width: 100%; height: 400px;">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Coming Soon Area -->
        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/smart-static-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/smart-static-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/smart-static-lander/js/bootstrap.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/smart-static-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/smart-static-lander/js/form-validator.min.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/smart-static-lander/js/wow.min.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/smart-static-lander/js/main.js"></script>
    </body>
</html>