<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/over-counter-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/over-counter-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/over-counter-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/over-counter-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/over-counter-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>

    </head>

    <body>
        
        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Coming Soon Area -->
        <section class="coming-soon-area">
            <div class="container-fluid p-0">
                <div class="row m-0">
                    <div class="col-lg-8 col-md-12 p-0">
                        <div class="coming-soon-image">
                            <img src="pages/landerthemes/over-counter-lander/img/background.jpg" alt="image">

                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>

                            <div id="timer">
                                <div id="days"></div>
                                <div id="hours"></div>
                                <div id="minutes"></div>
                                <div id="seconds"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-12 p-0">
                        <div class="coming-soon-content">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <h5>We'll see you soon</h5>
                                    <h1>extensionsdev Status 77 is coming soon</h1>


                                    <div class="social">
                                        <ul>
                                            <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                                            <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                                            <li><a href="/?a=about">About | &nbsp;</a></li>
                                            <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Coming Soon Area -->
        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/over-counter-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/over-counter-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/over-counter-lander/js/bootstrap.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/over-counter-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/over-counter-lander/js/form-validator.min.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/over-counter-lander/js/wow.min.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/over-counter-lander/js/main.js"></script>
    </body>
</html>