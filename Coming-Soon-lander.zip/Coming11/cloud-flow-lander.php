<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/cloud-flow-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/cloud-flow-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/cloud-flow-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/cloud-flow-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/cloud-flow-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-circle"></div>
                <span>E</span>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Navbar Area -->
        <div class="navbar-area">
            <div class="container">
                <div class="navbar-menu">
                    <div class="row align-items-center">
                        <div class="col-6 col-sm-6 col-md-6 col-lg-6">
                            <div class="logo">
                                <a><img src="img/logo.png" alt="image"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->

        <!-- Start Coming Soon Area -->
        <div class="coming-soon-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="coming-soon-content">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>

                            <h5>extensionsdev Status 77</h5>
                            <h1>Is Coming Soon</h1>
                            <p>An amazing new Chrome Extension is on its way.</p>

                            <div id="timer">
                                <div id="days"></div>
                                <div id="hours"></div>
                                <div id="minutes"></div>
                                <div id="seconds"></div>
                            </div>
                            <div class="link-third">
                                <ul>
                                    <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                                    <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                                    <li><a href="/?a=about">About | &nbsp;</a></li>
                                    <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Coming Soon Area -->
        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/bootstrap.min.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/wow.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/form-validator.min.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/cloud-flow-lander/js/main.js"></script>
    </body>
</html>