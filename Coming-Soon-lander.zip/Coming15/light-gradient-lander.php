<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/light-gradient-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/light-gradient-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/light-gradient-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/light-gradient-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/light-gradient-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Navbar Area -->
        <div class="navbar-area">
            <div class="container">
                <div class="navbar-menu">
                    <div class="row align-items-center">
                        <div class="col-6 col-sm-6 col-md-6 col-lg-6">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        
        <!-- Start Main Banner -->
        <div class="main-banner">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="main-banner-content">
                            <h1>extensionsdev Status 77</h1>
                            <p>An amazing new Chrome Extension is on its way.</p>

                            <div class="newsletter-form">
                                <button type="submit"><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION" style="color: #fff;">Install</a></button>
                            </div>
                        </div>

                        <div class="countdown-timer">
                            <div class="inner-content">
                                <h3>Comming In</h3>

                                <div id="timer">
                                    <div id="days"></div>
                                    <div id="hours"></div>
                                    <div id="minutes"></div>
                                    <div id="seconds"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Area -->
            <footer class="footer-area">
                <div class="container">
                    <ul>
                        <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                        <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                        <li><a href="/?a=about">About | &nbsp;</a></li>
                        <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                    </ul>
                </div>
            </footer>
            <!-- End Footer Area -->
        </div>
        <!-- End Main Banner -->
        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/bootstrap.min.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/wow.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/form-validator.min.js"></script>
        <!-- Contact Form Min JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/contact-form-script.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/light-gradient-lander/js/main.js"></script>
    </body>
</html>