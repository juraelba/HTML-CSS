<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/static-purple-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/static-purple-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/static-purple-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/static-purple-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/static-purple-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-circle"></div>
                <span>E</span>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Navbar Area -->
        <div class="navbar-area">
            <div class="container">
                <div class="navbar-menu">
                    <div class="row align-items-center">
                        <div class="col-6 col-sm-6 col-md-6 col-lg-6">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->

        <!-- Start Coming Soon Area -->
        <section class="coming-soon-area">
            <div class="container-fluid p-0">
                <div class="row m-0 align-items-center">
                    <div class="col-lg-5 col-md-12 p-0">
                        <div class="coming-soon-image">
                            <img src="pages/landerthemes/static-purple-lander/img/background.jpg" alt="image">
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-12 p-0">
                        <div class="coming-soon-content">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <h5>extensionsdev Status 77</h5>
                                    <h1>Coming Soon</h1>
                                    <p>An amazing new Chrome Extension is on its way.</p>

                                    <div id="timer">
                                        <div id="days"></div>
                                        <div id="hours"></div>
                                        <div id="minutes"></div>
                                        <div id="seconds"></div>
                                    </div>
                                    <div class="link-third">
                                        <ul>
                                            <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                                            <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                                            <li><a href="/?a=about">About | &nbsp;</a></li>
                                            <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="shape"><img src="pages/landerthemes/static-purple-lander/img/shape.png" alt="image"></div>
        </section>
        <!-- End Coming Soon Area -->

        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/static-purple-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/static-purple-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/static-purple-lander/js/bootstrap.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/static-purple-lander/js/form-validator.min.js"></script>
        <!-- Contact Form Min JS -->
        <script src="pages/landerthemes/static-purple-lander/js/contact-form-script.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/static-purple-lander/js/wow.min.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/static-purple-lander/js/main.js"></script>
    </body>
</html>