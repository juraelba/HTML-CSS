<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-image-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-image-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-image-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-image-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/smart-image-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>

    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-outter"></div>
                <div class="loader-inner"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Navbar Area -->
        <div class="navbar-area">
            <div class="container">
                <div class="navbar-menu">
                    <div class="row align-items-center">
                        <div class="col-6 col-sm-6 col-md-6 col-lg-6">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->
        
        <!-- Start Main Banner -->
        <div class="main-banner">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-lg-7 col-md-12">
                                <div class="main-banner-content">
                                    <div id="timer">
                                        <div id="days"></div>
                                        <div id="hours"></div>
                                        <div id="minutes"></div>
                                        <div id="seconds"></div>
                                    </div>

                                    <h1>extensionsdev Status 77</h1>
                                    <p>An amazing new Chrome Extension is on its way.</p>
                                    <div class="newsletter-form">
                                        <button type="submit"><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION" style="color: #fff;">Install</a></button>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-5 col-md-12">
                                <div class="main-banner-image">
                                    <img src="pages/landerthemes/smart-image-lander/img/image.png" alt="image">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <footer class="footer-area">
                <div class="container">
                    <ul>
                        <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                        <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                        <li><a href="/?a=about">About | &nbsp;</a></li>
                        <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                    </ul>
                </div>
            </footer>
        </div>
        <!-- End Main Banner -->

        <!-- Sidebar Modal -->
        <div class="sidebar-modal">
            <div class="sidebar-modal-inner">
                <div class="about-area">
                    <div class="title">
                        <h2>About Us</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis suspendisse ultrices gravida. Risus commodo viverra. Quis suspendisse ultrices gravida.</p>
                    </div>
                </div>

                <div class="contact-area">
                    <div class="title">
                        <h2>Contact Us</h2>
                    </div>

                    <div class="contact-form">
                        <form id="contactForm">
                            <div class="form-group">
                                <input type="text" name="name" id="name" class="form-control" required data-error="Please enter your name" placeholder="Name">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <input type="email" name="email" id="email" class="form-control" required data-error="Please enter your email" placeholder="Email">
                                <div class="help-block with-errors"></div>
                            </div>

                            <div class="form-group">
                                <textarea name="message" class="form-control" id="message" cols="30" rows="5" required data-error="Write your message" placeholder="Your Message"></textarea>
                                <div class="help-block with-errors"></div>
                            </div>

                            <button type="submit">Send Message</button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>
                        </form>
                    </div>

                    <div class="contact-info">
                        <div class="contact-info-content">
                            <h3>Contact us by Phone Number or Email Address</h3>
                            <h2>
                                <a href="tel:+0881306298615">+088 130 629 8615</a>
                                <span>OR</span>
                                <a href="mailto:emilono@gmail.com">emilono@gmail.com</a>
                            </h2>
    
                            <ul class="social">
                                <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-youtube"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <span class="close-btn sidebar-modal-close-btn"><i class="fas fa-times"></i></span>
            </div>
        </div>
        <!-- End Sidebar Modal -->
        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/bootstrap.min.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/wow.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/form-validator.min.js"></script>
        <!-- Contact Form Min JS -->
        <script src="pages/landerthemes/smart-image-lander/js/contact-form-script.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/smart-image-lander/js/main.js"></script>
    </body>
</html>