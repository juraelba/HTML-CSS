<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/beatiful-complex-lander/css/bootstrap.min.css">
        <!-- Animate Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/beatiful-complex-lander/css/animate.min.css">
        <!-- FontAwesome Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/beatiful-complex-lander/css/fontawesome.min.css">
        <!-- Style Min CSS -->
        <link rel="stylesheet" href="pages/landerthemes/beatiful-complex-lander/css/style.css">
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="pages/landerthemes/beatiful-complex-lander/css/responsive.css">

        <title>extensionsdev Status 77</title>
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="loader-circle"></div>
                <span>E</span>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Navbar Area -->
        <div class="navbar-area">
            <div class="container">
                <div class="navbar-menu">
                    <div class="row align-items-center">
                        <div class="col-6 col-sm-6 col-md-6 col-lg-6">
                            <div class="logo">
                                <a href="index.html"><img src="img/logo.png" alt="image"></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- End Navbar Area -->

        <!-- Start Coming Soon Area -->
        <div class="coming-soon-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col-lg-5 col-md-12">
                                <div class="countdown-timer">
                                    <div id="timer">
                                        <div id="days"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-7 col-md-12">
                                <div class="coming-soon-content">
                                    <div class="logo">
                                        <a href="index.html"><img src="img/logo.png" alt="image"></a>
                                    </div>
                                    <h1>extensionsdev Status 77 is coming soon!</h1>
                                    <p>An amazing new Chrome Extension is on its way.</p>


                                    <div class="social">
                                        <ul>
                                            <li><a href="/?a=privacy">Privacy | &nbsp;</a></li>
                                            <li><a href="/?a=terms">Terms | &nbsp;</a></li>
                                            <li><a href="/?a=about">About | &nbsp;</a></li>
                                            <li><a href="https://chrome.google.com/webstore/detail/REPLACEEXTENSION">Install Now</a></i></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="shape1"><img src="pages/landerthemes/beatiful-complex-lander/img/shape1.png" alt="image"></div>
            <div class="shape2"><img src="pages/landerthemes/beatiful-complex-lander/img/shape2.png" alt="image"></div>
            <div class="shape3"><img src="pages/landerthemes/beatiful-complex-lander/img/shape3.png" alt="image"></div>
            <div class="shape4"><img src="pages/landerthemes/beatiful-complex-lander/img/shape4.png" alt="image"></div>
            <div class="shape5"><img src="pages/landerthemes/beatiful-complex-lander/img/shape5.png" alt="image"></div>
            <div class="shape6"><img src="pages/landerthemes/beatiful-complex-lander/img/shape6.png" alt="image"></div>
            <div class="shape7"><img src="pages/landerthemes/beatiful-complex-lander/img/shape7.png" alt="image"></div>
            <div class="shape8"><img src="pages/landerthemes/beatiful-complex-lander/img/shape8.png" alt="image"></div>
            <div class="shape9"><img src="pages/landerthemes/beatiful-complex-lander/img/shape9.png" alt="image"></div>
            <div class="shape10"><img src="pages/landerthemes/beatiful-complex-lander/img/shape10.png" alt="image"></div>
            <div class="shape11"><img src="pages/landerthemes/beatiful-complex-lander/img/shape11.png" alt="image"></div>
            <div class="shape12"><img src="pages/landerthemes/beatiful-complex-lander/img/shape12.png" alt="image"></div>
            <div class="shape13"><img src="pages/landerthemes/beatiful-complex-lander/img/shape13.png" alt="image"></div>
        </div>
        <!-- End Coming Soon Area -->

        
        <!-- jQuery Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/jquery.min.js"></script>
        <!-- Popper Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/popper.min.js"></script>
        <!-- Bootstrap Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/bootstrap.min.js"></script>
        <!-- AjaxChimp Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/jquery.ajaxchimp.min.js"></script>
        <!-- Form Validator Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/form-validator.min.js"></script>
        <!-- Contact Form Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/contact-form-script.js"></script>
        <!-- WOW Min JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/wow.min.js"></script>
        <!-- Main JS -->
        <script src="pages/landerthemes/beatiful-complex-lander/js/main.js"></script>
    </body>
</html>