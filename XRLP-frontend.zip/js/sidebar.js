$(document).ready(function() {
    $('#sidebarCollapse').on('click', function() {
        $('.wrapper').toggleClass('active');
    });
});