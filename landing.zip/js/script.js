// fixed/sticky header
$(window).scroll(function() {
  var sticky = $('header'),
    scroll = $(window).scrollTop();

  if (scroll >= 40) sticky.addClass('fixed');
  else sticky.removeClass('fixed');
});

// Active Menu
$('header .navbar-nav.h-middle .nav-link').on('click', function(){
    $(this).addClass('active').siblings().removeClass('active');
	
});

// tabs
function openCity(evt, cityName) {
	var i, tabcontent, tablinks;  
	tabcontent = document.getElementsByClassName("tabcontent");  
	for (i = 0; i < tabcontent.length; i++) {
		tabcontent[i].style.display = "none";  
	}
		tablinks = document.getElementsByClassName("tablinks");
	for (i = 0; i < tablinks.length; i++) {
		tablinks[i].className = tablinks[i].className.replace(" active", "");
	}  
	document.getElementById(cityName).style.display = "block";
	evt.currentTarget.className += " active";
}



/*Filter Menu*/
$('.filter').click(function () {
        $(this).attr('tabindex', 1).focus();
        $(this).toggleClass('active');
        $(this).find('.dropdown-menu').slideToggle(300);
    });
    $('.filter').focusout(function () {
        $(this).removeClass('active');
        $(this).find('.dropdown-menu').slideUp(300);
    });
    $('.filter .dropdown-menu li').click(function () {
        $(this).parents('.filter').find('span').text($(this).text());
        $(this).parents('.filter').find('input').attr('value', $(this).attr('id'));
    });
	
	$('.filter .dropdown-menu li').click(function () {
        $(this).parents('.filter').find('span').text($(this).text());
        $(this).parents('.filter').find('input').attr('value', $(this).attr('id'));
    });
	
$('.filter .dropdown-menu li').on('click', function(){
    $(this).addClass('active').siblings().removeClass('active');
});
/*End Dropdown Menu*/
 